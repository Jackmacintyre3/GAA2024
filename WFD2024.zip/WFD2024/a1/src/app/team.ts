export interface Team {    
    name: string
}
