import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Player } from './player';
import { Team } from './team';

@Injectable({
  providedIn: 'root'
})
export class PlayersService {

  playerURL = "http://localhost:3000/players/"
  teamURL = "http://localhost:3000/teams/"

  constructor(private http: HttpClient){
  }


  getPlayers() : Observable<Player[]>{
    return this.http.get<Player[]>(this.playerURL);
  }

  
  // See the REST API server code to get the teams
  getPlayerTeams() : Observable<Team[]>{
    return this.http.get<Team[]>(this.teamURL);
  }

  
}
