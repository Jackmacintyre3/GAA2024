export interface Player {
    id: number,
    name: string,
    team: string,
    squadNumber: number
}
