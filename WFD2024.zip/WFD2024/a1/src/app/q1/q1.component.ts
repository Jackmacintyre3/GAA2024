import { DecimalPipe } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-q1',
  templateUrl: './q1.component.html',
  styleUrls: ['./q1.component.css']
})
export class Q1Component {

  intervalID: any;
  totalSeconds = 120;
  seconds = this.totalSeconds;
  caption = "Start";
  caption2 = "Reset";
  isRunning = false;
  ss = this.totalSeconds % 60;
  mm = Math.floor(this.totalSeconds / 60);

  startStop() {
    if (this.isRunning) {
      clearInterval(this.intervalID);
      this.caption = "Start";
    } else {
      this.intervalID = setInterval(() => {
        if (this.seconds > 0) {
          this.seconds--;
          this.ss = this.seconds % 60;
          this.mm = Math.floor(this.seconds / 60);
          console.log('tick', this.mm, 'minutes', this.ss, 'seconds');
        } else {
          clearInterval(this.intervalID);
        }
      }, 1000);
      this.caption = "Stop";
    }
    this.isRunning = !this.isRunning;
  }

  reset() {
    clearInterval(this.intervalID);
    this.seconds = this.totalSeconds;
    this.ss = this.totalSeconds % 60;
    this.mm = Math.floor(this.totalSeconds / 60);
    this.isRunning = false;
    this.caption = "Start";
  }

  get progress() {
    return (this.seconds / this.totalSeconds) * 100;
  }
}