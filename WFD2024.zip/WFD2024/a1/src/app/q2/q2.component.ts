import { UpperCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-q2',
  standalone: true,
  imports: [UpperCasePipe, ReactiveFormsModule],
  templateUrl: './q2.component.html',
  styleUrl: './q2.component.css'
})
export class Q2Component {

  imageURL = "./assets/visa_card_front.png";   
  BackImageURL = "./assets/card_back.png";

  contactForm = new FormGroup({

    card_number: new FormControl(''),
    card_name: new FormControl(''),
    card_type: new FormControl('visa')
    
  });

  get card_name() {
    return this.contactForm.get('card_name')?.value;
  }

  get card_number() {
    return this.contactForm.get('card_number')?.value;
  }

  updateImage(event: Event) {
    const cardType = (event.target as HTMLSelectElement).value;
    this.imageURL = `./assets/${cardType}_card_front.png`;
    
  }
}