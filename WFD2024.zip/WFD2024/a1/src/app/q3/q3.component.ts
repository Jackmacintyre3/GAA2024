import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Player } from '../player';
import { PlayersService } from '../players.service';

@Component({
  selector: 'app-q3',
  standalone: true,
  imports: [],
  templateUrl: './q3.component.html',
  styleUrls: ['./q3.component.css']
})
export class Q3Component {

  players: Player[] = [];  
  teams: string[] = [];

  constructor(private playerService: PlayersService) {
    this.playerService.getPlayers().subscribe(
      response => {
        this.players = response;        
        this.teams = [...new Set(this.players.map(player => player.team))];
        console.log(response);
      }
    );
  }
}