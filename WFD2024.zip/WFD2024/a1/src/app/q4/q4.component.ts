// q4.component.ts
import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { Player } from '../player';
import { PlayersService } from '../players.service';
import { Team } from '../team';

@Component({
  selector: 'app-q4',
  templateUrl: './q4.component.html',
  styleUrls: ['./q4.component.css']
})
export class Q4Component {
applyFilter($event: Event) {
throw new Error('Method not implemented.');
}
  players: Player[] = [];
  teams: Team[] = [];
  filter = new FormControl('');
  filteredPlayers: Observable<Player[]>;

  constructor(private playerService: PlayersService) {
    this.playerService.getPlayers().subscribe(response => {
      this.players = response;
      console.log(response);
    });

    this.playerService.getPlayerTeams().subscribe(response => {
      this.teams = response;
      console.log(response);
    });

    this.filteredPlayers = this.filter.valueChanges.pipe(
      startWith(''),
      map(value => this._filterPlayers(value ?? ''))
    );
  }

  private _filterPlayers(value: string): Player[] {
    const filterValue = value.toLowerCase();
    return this.players.filter(player => player.name.toLowerCase().includes(filterValue));
  }

  onDeleteClick(playerId: number) {
  //Delete
  }
}
