var express = require("express");
var bodyParser = require("body-parser");

// 
var model = require('./model/db.js');  //

var cors = require('cors')
var app = express();


// serves files in public folder
app.use(express.static('public'));

// NB:: this must be included to get JSON content sent with requests
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

app.use(cors());


// setup REST API /team route VERBS - GET, POST, PUT, DELETE
app.route('/teams')
  .get(function (req, res) {  
    model.getTeams(req, res);
  })

app.route('/players')
  .get(function (req, res) {  
    model.getPlayers(req, res);   
  })

  app.route('/players')
  .delete(function (req, res) {  
    model.deletePlayer(req, res);   
  })

  
var myServer = app.listen(3000, function() {
  console.log("Server listening on port 3000");
});
