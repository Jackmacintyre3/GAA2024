var mysql = require('mysql');

///////////////////////////////////////////////////////////////////////////////////////////

// Setup MySQL connection
// timezone is very NB

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'wfd2024a1',
  timezone: 'utc+0'  
});

connection.connect(function(err){
	if(err) throw err;
	console.log(`Sucessfully connected to MySQL database wfd2024a1`);
});

///////////////////////////////////////////////////////////////////////////////////////////

// GET /players
exports.getPlayers = function(req,res){

    connection.query(`SELECT * FROM players`, function(err, rows, fields) {
        if (err) throw err;

        res.status(200);  // OK
        res.send(JSON.stringify(rows));	  
    });	
}

// GET /teams
exports.getTeams = function(req,res){

    connection.query(`SELECT DISTINCT team FROM players`, function(err, rows, fields) {
        if (err) throw err;

        res.status(200);  // OK
        res.send(JSON.stringify(rows));	  
    });	
}

exports.deletePlayer = function(req, res){
    connection.query(`DELETE FROM players WHERE id = ?`, [req.params.id], function(err, rows, fields) {
        if(err) throw err;
        res.status(200);
        res.send(JSON.stringify(rows));	    
    });
}